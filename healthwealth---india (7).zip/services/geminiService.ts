
import { GoogleGenAI, Type } from "@google/genai";
import { LocationType, PointOfInterest, Quest, Scenario } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getTacticalAdvice(scenario: Scenario, findings: string[], userQuery?: string): Promise<string> {
  try {
    const contents = userQuery 
      ? `AGENT QUERY: "${userQuery}". CONTEXT: Investigation of "${scenario.title}". FIELD DATA: [${findings.join(", ")}]. Provide a condensed, brief tactical response (max 2 sentences) in the persona of a Bio-Economic Spy HQ. Deliver main points only.`
      : `FIELD DATA: [${findings.join(", ")}]. CONTEXT: "${scenario.title}". Provide a single brief sentence of tactical operative advice.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: contents,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "Tactical link weak. Proceed with intuition.";
  } catch (e) {
    return "Tactical link unstable. Rely on primary operative training.";
  }
}

export async function gradeMultipleFreeResponses(items: { question: string, answer: string }[]): Promise<{ score: number, feedback: string }[]> {
  if (items.length === 0) return [];
  try {
    const prompt = items.map((it, i) => `Q${i+1}: ${it.question}\nA${i+1}: ${it.answer}`).join("\n\n");
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Evaluate these field reports. Be lenient and encouraging: if the answer shows a basic understanding of the concept, give a high score (0.8-1.0). Only penalize for completely incorrect or irrelevant info. Return JSON array of objects {score (0-1), feedback (max 10 words)}. Persona: Spy HQ.\n\n${prompt}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER },
              feedback: { type: Type.STRING }
            },
            required: ["score", "feedback"]
          }
        }
      }
    });
    return JSON.parse(response.text.trim());
  } catch (e) {
    return items.map(() => ({ score: 0.5, feedback: "Neural link timeout." }));
  }
}

export async function gradeFreeResponse(question: string, answer: string): Promise<{ score: number, feedback: string, positives: string, negatives: string }> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Evaluate operative field report. Topic: "${question}". Report: "${answer}". Return JSON {score, feedback, positives, negatives}. Use Spy persona. Keep feedback brief and condensed.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            feedback: { type: Type.STRING },
            positives: { type: Type.STRING },
            negatives: { type: Type.STRING }
          },
          required: ["score", "feedback"]
        }
      }
    });
    const data = JSON.parse(response.text.trim());
    return {
      score: data.score ?? 0.5,
      feedback: data.feedback ?? "Analysis synchronized.",
      positives: data.positives ?? "Protocol followed.",
      negatives: data.negatives ?? "No breaches found."
    };
  } catch (e) {
    return { score: 0.5, feedback: "Neural link offline.", positives: "Data captured.", negatives: "Logic buffer error." };
  }
}

export async function generateQuest(location: LocationType, poi: PointOfInterest, day: number): Promise<Quest> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a 3-stage Interactive Educational Bio-Economic Spy Quest for ${poi.name} in ${location}.
      
      COMPLEXITY RULES:
      1. Every stage MUST have exactly 5 Investigation Nodes.
      2. The investigation nodes must contain clues that BUILD a case for a complicated dilemma.
      3. Use ONLY universally known 3-char health/tech acronyms for puzzle codes: AQI, BPM, DNA, BMI, ICU, BP, ER, ORS, ECG, MRI.
      4. Decision dilemma: Trade-off between immediate health (High Cost) vs Long-term Buffer (Infrastructure/Generics).
      5. Ensure clues are extremely intuitive and solvable by a general audience (e.g. AQI for air quality, BPM for heart rate, DNA for genetic code, BP for blood pressure).
      6. Reserve Costs for options MUST be in the range of 500 to 2000.
      7. OBSTACLES: Every stage MUST have 3-5 obstacles. Types: "block", "hazard", "slow".
      8. HARD DECISIONS: Options must have severe trade-offs. 
         - Protocol A: High Vitality (+25% HP), High Cost (1500+ Reserves), Low Resilience.
         - Protocol B: Balanced (+10% HP), Moderate Cost (800 Reserves), Moderate Resilience.
         - Protocol C: Low Cost (500 Reserves), Health Loss (-5% HP), High Resilience (Long-term play).
      
      JSON FORMAT:
      {
        "missionCodename": "OPERATION [NARRATIVE NAME]",
        "title": "Tactical Objective",
        "reflection": "Synchronization summary",
        "scenarios": [
          {
            "id": "string",
            "title": "Stage Title",
            "description": "Narrative setting the dilemma",
            "missionRisk": "Low" | "Moderate" | "High" | "Critical",
            "healthFact": "Informative healthcare takeaway",
            "synthesisAnalysis": "Tactical breakdown of gather intel",
            "investigationPoints": [
              {
                "id": "string",
                "subLocation": "Evidence Site",
                "description": "What is being audited",
                "clueResult": "The specific healthcare insight found",
                "requiredTool": "bio-scan" | "sig-int" | "hum-int",
                "puzzleCode": "3-char Acronym",
                "puzzleClue": "Very simple hint",
                "icon": "virus" | "water" | "doctor" | "trash" | "pills" | "microscope" | "heart" | "house" | "dna",
                "x": number,
                "y": number
              }
            ],
            "obstacles": [
              {
                "id": "string",
                "type": "block" | "hazard" | "slow",
                "name": "Obstacle Name",
                "icon": "Emoji icon",
                "x": number,
                "y": number,
                "radius": number
              }
            ],
            "options": [
              { 
                "label": "Protocol A (Reserves Heavy)", 
                "cost": number, 
                "healthEffect": number, 
                "resilienceImpact": number,
                "timeCost": number, 
                "feedback": "Brief condensed consequence" 
              },
              { "label": "Protocol B (Vitality Balanced)", ... },
              { "label": "Protocol C (Risk Aggressive)", ... }
            ]
          }
        ]
      }`,
      config: {
        responseMimeType: "application/json"
      }
    });

    const data = JSON.parse(response.text);
    const scenarios: Scenario[] = (data.scenarios || []).map((s: any) => ({
      id: s.id || String(Math.random()),
      title: s.title || "Stage",
      description: s.description || "Mission setting...",
      missionRisk: s.missionRisk || "Moderate",
      healthFact: s.healthFact || "Stay healthy.",
      synthesisAnalysis: s.synthesisAnalysis || "",
      investigationPoints: (s.investigationPoints || []).slice(0, 5).map((p: any) => ({
        id: p.id || String(Math.random()),
        subLocation: p.subLocation || "Site",
        description: p.description || "Audit...",
        clueResult: p.clueResult || "Insight...",
        requiredTool: p.requiredTool || "bio-scan",
        puzzleCode: String(p.puzzleCode || "DNA").toUpperCase(),
        puzzleClue: p.puzzleClue || "Hint...",
        icon: p.icon || "pills",
        x: p.x || 50,
        y: p.y || 50
      })),
      obstacles: (s.obstacles || []).map((o: any) => ({
        id: o.id || String(Math.random()),
        type: o.type || "hazard",
        name: o.name || "Obstacle",
        icon: o.icon || "⚠️",
        x: o.x || 50,
        y: o.y || 50,
        radius: o.radius || 5
      })),
      options: (s.options || []).map((o: any) => ({
        label: o.label || "Option",
        cost: o.cost || 0,
        healthEffect: o.healthEffect || 0,
        resilienceImpact: o.resilienceImpact || 0,
        timeCost: o.timeCost || 0,
        feedback: o.feedback || "Result..."
      }))
    })).slice(0, 3);

    return {
      poiId: poi.id,
      missionCodename: data.missionCodename || "OPERATION AYUSH",
      title: data.title || "Health Objective",
      scenarios: scenarios,
      reflection: data.reflection || "Sector synchronized.",
      currentStep: 0
    };
  } catch (e) {
    return {
      poiId: poi.id,
      missionCodename: "FALLBACK-OS",
      title: "Bio-Security Routine",
      reflection: "Standard field analysis protocol initiated.",
      currentStep: 0,
      scenarios: []
    };
  }
}
